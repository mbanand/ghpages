## ----htmltools-attrs-executed-------------------------------------------------
library(htmltools)
library(shiny.webawesome)

button_with_attrs <- tagAppendAttributes(
  wa_button("save_button", "Save"),
  `aria-label` = "Save current form",
  title = "Save"
)

cat(as.character(button_with_attrs), sep = "\n")

## ----htmltools-attrs-basic, eval = FALSE--------------------------------------
# library(htmltools)
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Extra attributes",
#   tagAppendAttributes(
#     wa_button("save_button", "Save"),
#     `aria-label` = "Save current form",
#     title = "Save"
#   )
# )
# 
# server <- function(input, output, session) {}
# 
# shinyApp(ui, server)

## ----htmltools-attrs-advanced, eval = FALSE-----------------------------------
# library(htmltools)
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "More attributes",
#   tagAppendAttributes(
#     wa_card("Keyboard focus example"),
#     role = "region",
#     tabindex = "0",
#     `data-section` = "summary"
#   )
# )
# 
# server <- function(input, output, session) {}
# 
# shinyApp(ui, server)

