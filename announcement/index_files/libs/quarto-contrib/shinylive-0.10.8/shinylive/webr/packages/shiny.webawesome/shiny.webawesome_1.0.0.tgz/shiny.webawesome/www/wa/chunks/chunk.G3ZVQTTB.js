/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  en_default
} from "./chunk.5OV4QM6R.js";
import {
  LocalizeController,
  registerTranslation
} from "./chunk.HPOJN4W7.js";

// src/utilities/localize.ts
var LocalizeController2 = class extends LocalizeController {
};
registerTranslation(en_default);

export {
  LocalizeController2 as LocalizeController
};
