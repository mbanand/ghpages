/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  dropdown_item_styles_default
} from "../../chunks/chunk.PWJU7FNZ.js";
import "../../chunks/chunk.7OBLIRXR.js";
import "../../chunks/chunk.BKE5EYM3.js";
import "../../chunks/chunk.JHZRD2LV.js";
export {
  dropdown_item_styles_default as default
};
