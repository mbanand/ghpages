/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  WaTextarea
} from "../../chunks/chunk.QEVO6VRC.js";
import "../../chunks/chunk.YRQJ7CY4.js";
import "../../chunks/chunk.I4KXAHPX.js";
import "../../chunks/chunk.346V4PTX.js";
import "../../chunks/chunk.KZZR6Z6I.js";
import "../../chunks/chunk.R7QX4M6R.js";
import "../../chunks/chunk.I3XGXHPO.js";
import "../../chunks/chunk.VC3BPUZJ.js";
import "../../chunks/chunk.KWDPKKFO.js";
import "../../chunks/chunk.KIHB3VMB.js";
import "../../chunks/chunk.MEYJNQF4.js";
import "../../chunks/chunk.3MSWQ3RG.js";
import "../../chunks/chunk.H23DVATU.js";
import "../../chunks/chunk.T3OVPJUT.js";
import "../../chunks/chunk.G3ZVQTTB.js";
import "../../chunks/chunk.5OV4QM6R.js";
import "../../chunks/chunk.HPOJN4W7.js";
import "../../chunks/chunk.PZAN6FPN.js";
import "../../chunks/chunk.K4C5PQDP.js";
import "../../chunks/chunk.7OBLIRXR.js";
import "../../chunks/chunk.BKE5EYM3.js";
import "../../chunks/chunk.JHZRD2LV.js";
export {
  WaTextarea as default
};
