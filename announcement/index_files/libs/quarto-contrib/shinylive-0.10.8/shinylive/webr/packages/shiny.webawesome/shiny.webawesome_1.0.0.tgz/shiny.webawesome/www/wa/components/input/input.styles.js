/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  input_styles_default
} from "../../chunks/chunk.BE5VT7MB.js";
import "../../chunks/chunk.7OBLIRXR.js";
import "../../chunks/chunk.BKE5EYM3.js";
import "../../chunks/chunk.JHZRD2LV.js";
export {
  input_styles_default as default
};
