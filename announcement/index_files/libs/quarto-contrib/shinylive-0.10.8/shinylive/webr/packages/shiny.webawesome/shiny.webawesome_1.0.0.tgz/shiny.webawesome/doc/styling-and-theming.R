## ----styling-and-theming-executed---------------------------------------------
library(shiny.webawesome)

themed_page <- webawesomePage(
  title = "Themed preview",
  class = "wa-theme-default wa-palette-default wa-brand-blue",
  wa_card("Styled preview")
)

cat(as.character(themed_page), sep = "\n")

## ----theming-default, eval = FALSE--------------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Themed page",
#   class = "wa-theme-default wa-palette-default wa-brand-blue",
#   wa_container(
#     class = "wa-stack",
#     style = "max-width: 32rem; margin: 2rem auto;",
#     wa_badge("Beta", appearance = "filled"),
#     wa_card("This page applies Web Awesome classes at the html root.")
#   )
# )
# 
# server <- function(input, output, session) {}
# 
# shinyApp(ui, server)

## ----theming-nondefault, eval = FALSE-----------------------------------------
# ui <- webawesomePage(
#   title = "Awesome theme",
#   class = "wa-theme-awesome wa-palette-bright wa-brand-blue",
#   wa_container(
#     style = "max-width: 32rem; margin: 2rem auto;",
#     wa_card("The matching Awesome theme stylesheet is attached automatically.")
#   )
# )

## ----component-class-style, eval = FALSE--------------------------------------
# wa_card(
#   "Styled card",
#   class = "my-card",
#   style = "max-width: 32rem;"
# )

