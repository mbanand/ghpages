## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  comment = "#>"
)

## ----get-started-version------------------------------------------------------
library(shiny.webawesome)

wa_version()

## ----get-started-preview------------------------------------------------------
button <- shiny.webawesome::wa_button("preview_button", "Preview")
cat(as.character(button), sep = "\n")

## ----fluid-page-mixed, eval = FALSE-------------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- fluidPage(
#   h2("Mixed Shiny page"),
#   wa_card(
#     header = "Status",
#     wa_badge("Beta", appearance = "filled"),
#     "This card is rendered inside fluidPage()."
#   )
# )
# 
# server <- function(input, output, session) {}
# 
# shinyApp(ui, server)

## ----basic-wrapper, eval = FALSE----------------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Basic wrappers",
#   wa_container(
#     class = "wa-stack",
#     style = "max-width: 32rem; margin: 2rem auto;",
#     wa_button(
#       "save_button",
#       "Save",
#       appearance = "filled",
#       style = "width: 10rem;"
#     ),
#     wa_card("A simple card body")
#   )
# )
# 
# server <- function(input, output, session) {}
# 
# shinyApp(ui, server)

## ----bindings, eval = FALSE---------------------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Bindings",
#   wa_select(
#     "favorite_letter",
#     wa_option("A", value = "a"),
#     wa_option("B", value = "b"),
#     wa_option("C", value = "c")
#   ),
#   verbatimTextOutput("selected_value")
# )
# 
# server <- function(input, output, session) {
#   output$selected_value <- renderPrint({
#     input$favorite_letter
#   })
# }
# 
# shinyApp(ui, server)

## ----command-api, eval = FALSE------------------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Command API",
#   actionButton("open_dialog", "Open dialog"),
#   wa_dialog(
#     "dialog",
#     "Dialog body"
#   )
# )
# 
# server <- function(input, output, session) {
#   observeEvent(input$open_dialog, {
#     wa_call_method("dialog", "show", session = session)
#   })
# }
# 
# shinyApp(ui, server)

## ----package-options, eval = FALSE--------------------------------------------
# options(
#   shiny.webawesome.warnings = list(
#     command_layer_debug = TRUE
#   )
# )

