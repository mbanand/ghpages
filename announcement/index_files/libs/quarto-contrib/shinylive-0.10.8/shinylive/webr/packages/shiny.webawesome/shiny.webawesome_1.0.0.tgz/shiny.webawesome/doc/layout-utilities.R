## ----layout-utilities-executed------------------------------------------------
library(shiny.webawesome)

layout_preview <- wa_container(
  class = "wa-stack",
  wa_card("First card"),
  wa_card("Second card")
)

cat(as.character(layout_preview), sep = "\n")

## ----wa-page-basic, eval = FALSE----------------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Layout utilities",
#   wa_container(
#     style = "max-width: 32rem; margin: 2rem auto;",
#     wa_card("Hello from Web Awesome")
#   )
# )
# 
# server <- function(input, output, session) {}
# 
# shinyApp(ui, server)

## ----wa-page-richer, eval = FALSE---------------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Page example",
#   wa_container(
#     class = "wa-stack",
#     style = "max-width: 32rem; margin: 2rem auto;",
#     wa_card("Top card"),
#     wa_button(
#       "primary_action",
#       "Continue",
#       appearance = "filled",
#       style = "width: 10rem;"
#     ),
#     wa_card("Bottom card")
#   )
# )
# 
# server <- function(input, output, session) {}
# 
# shinyApp(ui, server)

## ----wa-container-basic, eval = FALSE-----------------------------------------
# library(shiny.webawesome)
# 
# wa_container(
#   class = "wa-stack",
#   wa_card("First card"),
#   wa_card("Second card")
# )

## ----layout-example-stack, eval = FALSE---------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Stacked layout",
#   wa_container(
#     class = "wa-stack",
#     style = "max-width: 32rem; margin: 2rem auto;",
#     wa_card("Profile"),
#     wa_card("Recent activity"),
#     wa_button(
#       "refresh",
#       "Refresh",
#       appearance = "outlined",
#       style = "width: 10rem;"
#     )
#   )
# )
# 
# server <- function(input, output, session) {}
# 
# shinyApp(ui, server)

## ----layout-example-mixed, eval = FALSE---------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Mixed layout",
#   wa_container(
#     class = "wa-cluster",
#     wa_badge("Beta"),
#     wa_tag("Preview")
#   ),
#   wa_container(
#     class = "wa-stack",
#     style = "max-width: 32rem; margin: 2rem auto;",
#     wa_card("Main content"),
#     wa_card("Secondary content")
#   )
# )
# 
# server <- function(input, output, session) {}
# 
# shinyApp(ui, server)

