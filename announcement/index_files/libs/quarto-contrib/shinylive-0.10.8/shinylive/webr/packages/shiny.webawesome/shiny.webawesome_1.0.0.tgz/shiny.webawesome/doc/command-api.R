## ----command-api-executed-----------------------------------------------------
library(shiny.webawesome)

js_helper <- wa_js("console.log('shiny.webawesome command api vignette');")
cat(as.character(js_helper), sep = "\n")

## ----command-set-property, eval = FALSE---------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Set property",
#   actionButton("open_dialog", "Open dialog"),
#   wa_dialog(
#     "dialog",
#     label = "Example dialog",
#     "Dialog body"
#   )
# )
# 
# server <- function(input, output, session) {
#   observeEvent(input$open_dialog, {
#     wa_set_property("dialog", "open", TRUE, session = session)
#   })
# }
# 
# shinyApp(ui, server)

## ----command-call-method, eval = FALSE----------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Call method",
#   actionButton("show_details", "Show details"),
#   actionButton("hide_details", "Hide details"),
#   wa_details(
#     "details",
#     summary = "More information",
#     "Details body"
#   )
# )
# 
# server <- function(input, output, session) {
#   observeEvent(input$show_details, {
#     wa_call_method("details", "show", session = session)
#   })
# 
#   observeEvent(input$hide_details, {
#     wa_call_method("details", "hide", session = session)
#   })
# }
# 
# shinyApp(ui, server)

## ----command-browser-glue, eval = FALSE---------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Browser glue",
#   wa_js("
#     function publishDialogState() {
#       const dialog = document.getElementById('dialog');
# 
#       if (!dialog ||
#           !window.Shiny ||
#           typeof window.Shiny.setInputValue !== 'function') {
#         return;
#       }
# 
#       window.Shiny.setInputValue(
#         'dialog_open_state',
#         dialog.open,
#         { priority: 'event' }
#       );
#     }
# 
#     document.addEventListener('wa-show', function(event) {
#       if (event.target.id === 'dialog') {
#         publishDialogState();
#       }
#     });
# 
#     document.addEventListener('wa-after-hide', function(event) {
#       if (event.target.id === 'dialog') {
#         publishDialogState();
#       }
#     });
#   "),
#   wa_dialog(
#     "dialog",
#     label = "Example dialog",
#     "Dialog body"
#   ),
#   verbatimTextOutput("dialog_state")
# )
# 
# server <- function(input, output, session) {
#   output$dialog_state <- renderPrint({
#     input$dialog_open_state
#   })
# }
# 
# shinyApp(ui, server)

## ----command-options, eval = FALSE--------------------------------------------
# options(
#   shiny.webawesome.warnings = list(
#     command_layer_debug = TRUE
#   )
# )

