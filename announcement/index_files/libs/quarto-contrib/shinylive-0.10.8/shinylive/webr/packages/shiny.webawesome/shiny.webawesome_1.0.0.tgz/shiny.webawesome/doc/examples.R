## ----examples-executed--------------------------------------------------------
library(shiny.webawesome)

example_page <- webawesomePage(
  title = "Example preview",
  wa_container(
    class = "wa-stack",
    wa_badge("Preview"),
    wa_card("Small executable example")
  )
)

cat(as.character(example_page), sep = "\n")

## ----example-layout, eval = FALSE---------------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Project overview",
#   wa_container(
#     class = "wa-stack",
#     style = "max-width: 32rem; margin: 2rem auto;",
#     wa_badge("Preview"),
#     wa_card("Status: active"),
#     wa_button(
#       "refresh",
#       "Refresh",
#       appearance = "outlined",
#       style = "width: 10rem;"
#     ),
#     wa_card("Recent activity")
#   )
# )
# 
# server <- function(input, output, session) {}
# 
# shinyApp(ui, server)

## ----example-bindings, eval = FALSE-------------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Binding example",
#   wa_container(
#     class = "wa-stack",
#     style = "max-width: 36rem; margin: 2rem auto;",
#     wa_select(
#       "favorite_letter",
#       wa_option("A", value = "a"),
#       wa_option("B", value = "b"),
#       wa_option("C", value = "c")
#     ),
#     wa_switch("notifications_enabled", "Notifications"),
#     wa_tree(
#       "navigation_tree",
#       selection = "multiple",
#       wa_tree_item("Section A", id = "section_a"),
#       wa_tree_item("Section B", id = "section_b"),
#       wa_tree_item("Section C", id = "section_c")
#     ),
#     verbatimTextOutput("state")
#   )
# )
# 
# server <- function(input, output, session) {
#   output$state <- renderPrint({
#     list(
#       favorite_letter = input$favorite_letter,
#       notifications_enabled = input$notifications_enabled,
#       navigation_tree = input$navigation_tree
#     )
#   })
# }
# 
# shinyApp(ui, server)

## ----example-command, eval = FALSE--------------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Command example",
#   wa_container(
#     class = "wa-stack",
#     style = "max-width: 36rem; margin: 2rem auto;",
#     actionButton("open_dialog", "Open dialog"),
#     actionButton("show_details", "Show details"),
#     wa_dialog(
#       "dialog",
#       label = "Example dialog",
#       "Dialog body"
#     ),
#     wa_details(
#       "details",
#       summary = "More information",
#       "Details body"
#     )
#   )
# )
# 
# server <- function(input, output, session) {
#   observeEvent(input$open_dialog, {
#     wa_call_method("dialog", "show", session = session)
#   })
# 
#   observeEvent(input$show_details, {
#     wa_call_method("details", "show", session = session)
#   })
# }
# 
# shinyApp(ui, server)

