## ----package-options-executed-------------------------------------------------
old <- getOption("shiny.webawesome.warnings")
on.exit(options(shiny.webawesome.warnings = old), add = TRUE)

options(
  shiny.webawesome.warnings = list(
    command_layer_debug = TRUE
  )
)

getOption("shiny.webawesome.warnings")

## ----options-debug, eval = FALSE----------------------------------------------
# options(
#   shiny.webawesome.warnings = list(
#     command_layer_debug = TRUE
#   )
# )

## ----options-tree-warning, eval = FALSE---------------------------------------
# options(
#   shiny.webawesome.warnings = list(
#     missing_tree_item_id = FALSE
#   )
# )

## ----options-command-warning, eval = FALSE------------------------------------
# options(
#   shiny.webawesome.warnings = list(
#     command_layer = FALSE
#   )
# )

## ----options-multiple, eval = FALSE-------------------------------------------
# options(
#   shiny.webawesome.warnings = list(
#     command_layer = TRUE,
#     command_layer_debug = TRUE
#   )
# )

