/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  tab_panel_styles_default
} from "../../chunks/chunk.KESSODMC.js";
import "../../chunks/chunk.7OBLIRXR.js";
import "../../chunks/chunk.BKE5EYM3.js";
import "../../chunks/chunk.JHZRD2LV.js";
export {
  tab_panel_styles_default as default
};
