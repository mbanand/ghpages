## ----shiny-bindings-executed--------------------------------------------------
library(shiny.webawesome)

binding_preview <- wa_select(
  "favorite_letter",
  wa_option("A", value = "a"),
  wa_option("B", value = "b"),
  wa_option("C", value = "c")
)

cat(as.character(binding_preview), sep = "\n")

## ----binding-semantic, eval = FALSE-------------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Semantic binding",
#   wa_select(
#     "favorite_letter",
#     wa_option("A", value = "a"),
#     wa_option("B", value = "b"),
#     wa_option("C", value = "c")
#   ),
#   verbatimTextOutput("selected_value")
# )
# 
# server <- function(input, output, session) {
#   output$selected_value <- renderPrint({
#     input$favorite_letter
#   })
# }
# 
# shinyApp(ui, server)

## ----binding-semantic-dialog, eval = FALSE------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Semantic dialog state",
#   actionButton("open_dialog", "Open dialog"),
#   wa_dialog(
#     "dialog",
#     label = "Example dialog",
#     "Dialog body"
#   ),
#   verbatimTextOutput("dialog_state")
# )
# 
# server <- function(input, output, session) {
#   observeEvent(input$open_dialog, {
#     wa_call_method("dialog", "show", session = session)
#   })
# 
#   output$dialog_state <- renderPrint({
#     input$dialog
#   })
# }
# 
# shinyApp(ui, server)

## ----binding-semantic-tree, eval = FALSE--------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Semantic tree selection",
#   wa_tree(
#     "navigation_tree",
#     selection = "multiple",
#     wa_tree_item("Section A", id = "section_a"),
#     wa_tree_item("Section B", id = "section_b"),
#     wa_tree_item("Section C", id = "section_c")
#   ),
#   verbatimTextOutput("tree_value")
# )
# 
# server <- function(input, output, session) {
#   output$tree_value <- renderPrint({
#     input$navigation_tree
#   })
# }
# 
# shinyApp(ui, server)

## ----binding-action, eval = FALSE---------------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Action binding",
#   wa_button("run_action", "Run"),
#   verbatimTextOutput("click_count")
# )
# 
# server <- function(input, output, session) {
#   output$click_count <- renderPrint({
#     input$run_action
#   })
# }
# 
# shinyApp(ui, server)

## ----binding-action-payload, eval = FALSE-------------------------------------
# library(shiny)
# library(shiny.webawesome)
# 
# ui <- webawesomePage(
#   title = "Action with payload",
#   wa_dropdown(
#     "menu",
#     wa_dropdown_item("Alpha", value = "alpha"),
#     wa_dropdown_item("Beta", value = "beta"),
#     trigger = wa_button("menu_trigger", "Open menu")
#   ),
#   verbatimTextOutput("action_value"),
#   verbatimTextOutput("payload_value")
# )
# 
# server <- function(input, output, session) {
#   output$action_value <- renderPrint({
#     input$menu
#   })
# 
#   output$payload_value <- renderPrint({
#     input$menu_value
#   })
# }
# 
# shinyApp(ui, server)

